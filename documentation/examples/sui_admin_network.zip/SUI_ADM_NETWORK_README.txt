Sui Dynasty Administrative Hierarchy

Date of publication: 2008
Editor:  Lex Berman
Publisher:  CHGIS
Website:  www.fas.harvard.edu/~chgis

Description:

Using the CHGIS database, queries were designed to show the relationship between PARENT units in the administrative hierarchy and their subordinate units.  In this example, the capital of the subordinate Prefectures of the Sui Dynasty were queried, showing the locations of the parent and subordinate units, together with the valid period of time during which the relationship existed.

For example, a Prefecture A is subordinate to Capital A from Time 1 to Time 3, following with Prefecture B is subordinate to Capital A from Time 4 to Time 10, and so on.  The pairs of locations are constructed into line features in KML and the valid period of time is stamped on the features as BEGIN and END time values, using the Time Enabled KML application [teKML].

The resulting Time Enabled KML file shows the administrative hierarchy as a network of lines radiating from the National Capital at Chang'an down to the Prefecture capitals in the first file [SUI_ADM1-te.kml], and from the Prefectures down to their subordinate county seats in the second file [SUI_ADM2-te.kml]

See a fuller explanation here:  http://gist.fas.harvard.edu/chgis/?cat=8


Contents:
SUI_ADM1-te.kml
SUI_ADM2-te.kml

File character set encoding:
UTF-8

Related Links:

Download-- https://cga-download.hmdc.harvard.edu/publish_web/Geo_Tools/teKML/examples/
teKML--  https://cga-download.hmdc.harvard.edu/publish_web/Geo_Tools/teKML/

