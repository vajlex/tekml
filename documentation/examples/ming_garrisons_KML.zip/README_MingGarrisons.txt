Title:  "Ming Garrisons (1363-1644)"

Principal Investigator: Prof. Michael Szonyi
Editor: John Wong

With Funding from the Chiang Ching Kuo Foundation
website: http://www.cckf.org.tw/


(c) 2008
Released for Academic Use Only  (GPL license)

------------------

Citation:  Military Wei (Guards) and Suo (Battalions) of the Ming Dynasty (1368-1644)

This dataset is compiled from Liew, Foon Ming. The treatises on military affairs of the Ming dynastic history (1368-1644) : an annotated translation of the treatises on military affairs, chapter 89 and chapter 90 : supplemented by the treatises on military affairs of the draft of the Ming Dynastic History : a documentation of Ming-Qing historiography and the decline and fall of the Ming Empire (Hamburg : Gesellschaft f�r Natur- und V�lkerkunde Ostasiens, 1998.)

The geographic information is based on CHGIS V3 datasets.



-------------------

Distributed by CHGIS:
http://www.fas.harvard.edu/~chgis


------------------



